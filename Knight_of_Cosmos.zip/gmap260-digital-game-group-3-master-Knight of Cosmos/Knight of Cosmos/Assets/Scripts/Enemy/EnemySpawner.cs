﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public Transform[] spawnPoints = new Transform[5];
    private string[] enemyNames = { "Plasmatic", "Beemius", "Blastotron" };
    //Readd BoxPatrol and CircularPatrol after alpha
    private string[] movementTypes = { "UpDown", "LeftRight", "DiagonalPatrol", "CircularPatrol", "BoxPatrol" };
    private string[] attackTypes = { "MultiSpread", "SingleLinear", "SingleAimed" };

    
    //Singleton to allow access to the spawner
    private static EnemySpawner _instance;
    public static EnemySpawner Instance
    {
        get
        {
            if (_instance == null)
                Debug.LogError("Null enemy spawner");

            return _instance;
        }
    }

    private void Awake()
    {
        _instance = this;
    }

    /* Function called from WaveManager
     * For now, it spawns 3-5 enemies on the right half of the screen at fixed spawn points
     * No wave-based scaling implemented for alpha build
     * Furthermore, the arrays handling what components will be added must be vigilantly maintained and updated
     * Maintenance also includes the corresponding index ranges in the function
     */
    public void SpawnEnemies()
    {
        //Calculate wave-scaled health and fire rate
        int health = 5 + WaveManager.Instance.HealthBonus;
        float fireInterval = 2f - WaveManager.Instance.FireIntervalBonus;
        //Enemy fire rate is lowered depending on enemy count - no penalty for 3, + 0.2 seconds for 4, + 0.4 seconds for 5
        int spawnCount = Random.Range(3, 6);
        float spawnPenalty = (spawnCount - 3) * 0.2f;
        fireInterval += spawnPenalty;
        int enemyIndex;
        int spawnIndex;
        int movementIndex;
        int attackIndex;
        List<int> occupiedSpawns = new List<int>();

        //Spawns given number of enemies out of specific enemy pool at non-repeating spawn points
        for (int i = 0; i < spawnCount; i++)
        {
            enemyIndex = Random.Range(0, 3);
            movementIndex = Random.Range(0, movementTypes.Length);
            attackIndex = Random.Range(0, attackTypes.Length);
            do
            {
                spawnIndex = Random.Range(0, 5);
            } while (occupiedSpawns.Contains(spawnIndex));
            occupiedSpawns.Add(spawnIndex);
            
            //Request from the object pool
            GameObject enemyObj = EnemyObjectPool.Instance.SpawnFromPool(enemyNames[enemyIndex], spawnPoints[spawnIndex].position, Quaternion.identity);
            
            //Construct enemy parameters
            Enemy enemy = enemyObj.GetComponent<Enemy>();
            enemy.Initialize(health, fireInterval, movementTypes[movementIndex], attackTypes[attackIndex]);
            
            //Begin enemy behavior
            IPooledObject pooledObj = enemyObj.GetComponent<IPooledObject>();
            if (pooledObj != null)
            {
                pooledObj.OnObjectSpawn();
            }
        }
    }
}
