﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveManager : MonoBehaviour
{

    //Manage spawn process
    public enum SpawnState { Spawning, Waiting, Counting };

    public float timeBetweenWaves = 5f;
    public float waveCountdown;

    private int plasmaticCount;
    private int beemiusCount;
    private int blastotronCount;
    public int waveCounter = 0;
    private SpawnState state = SpawnState.Waiting;
    private bool isTransition = false;
    public WaveCounter counter;
    public Animator Orion;
    public Animator BlackHole;
    public AudioSource TransitionSound;

    //Enemy scaling modifiers: faster fire rate, more health, extra bullet on spread attacks
    public float FireIntervalBonus { get; set; } = 0f;
    public int HealthBonus { get; set; } = 0;
    public int ShotBonus { get; set; } = 0;
    
    //Enemies no longer scale after the 25th wave, capping out enemies at 4x fire rate (0.5 to 1.5), 2x health (10), and 2x bullets on multi attacks (6)
    private int waveScaleCap = 25;

    //Singleton to allow access to the manager
    private static WaveManager _instance;
    public static WaveManager Instance
    {
        get
        {
            if (_instance == null)
                Debug.LogError("Null wave manager");

            return _instance;
        }
    }

    private void Awake()
    {
        _instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        waveCountdown = timeBetweenWaves;
    }

    // Update is called once per frame
    void Update()
    {
        if (state == SpawnState.Waiting)
        {
            //Check if there are any enemies remaining
            plasmaticCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Plasmatic");
            beemiusCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Beemius");
            blastotronCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Blastotron");
            if ((plasmaticCount + beemiusCount + blastotronCount) == 0)
            {
                state = SpawnState.Counting;
            }
        }
        //Begin a countdown to spawn the wave
        else if (state == SpawnState.Counting)
        {
            if (waveCountdown <= 0)
            {
                state = SpawnState.Spawning;
                //Play a transition scene with Orion and the worm hole after each 5th wave completion
                if (waveCounter % 5 == 0 && waveCounter != 0)
                {
                    StartCoroutine("TransitionScene");
                }
            }
            else
            {
                waveCountdown -= Time.deltaTime;
            }
            
        }
       //Reset the timer and keep track of current wave
       else if (state == SpawnState.Spawning && !isTransition)
        {
            waveCountdown = timeBetweenWaves;
            waveCounter++;
            //Every 5th wave until the 25th scale the enemy stats
            if (waveCounter % 5 == 0 && waveCounter <= waveScaleCap)
            {
                ScaleEnemies();
            }
            EnemySpawner.Instance.SpawnEnemies();
            state = SpawnState.Waiting;
            counter.SetCounter(waveCounter);
        }

    }

    void ScaleEnemies()
    {
        FireIntervalBonus += 0.3f;
        HealthBonus += 2;
        //A bullet is added on waves 5, 10, 20 to multi spread
        if (waveCounter == 5 || waveCounter == 10 || waveCounter == 20)
        {
            ShotBonus++;
        }
    }

    IEnumerator TransitionScene()
    {
        isTransition = true;
        Orion.SetTrigger("Onward");
        BlackHole.SetTrigger("Onward");
        TransitionSound.Play();
        yield return new WaitForSeconds(2f);
        isTransition = false;
    }
}
