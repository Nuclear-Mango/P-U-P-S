﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Object Pooler for enemies and their projectiles
public class EnemyObjectPool : MonoBehaviour
{
    //Singleton to allow access to the pool
    private static EnemyObjectPool _instance;
    public static EnemyObjectPool Instance
    {
        get
        {
            if (_instance == null)
                Debug.LogError("Null object pool");
            
            return _instance;
        }
    }

    //Inspector editable pooling for multiple arbitrary objects
    [System.Serializable]
    public class Pool
    {
        public string tag;
        public GameObject prefab;
        public int size;
    }

    //Set the singleton
    private void Awake()
    {
        _instance = this;
    }

    /*Object types are held in pools
     * The dictionary associates each pool of objects with their tag as a key for lookup purposes
     * A queue orders the objects in each individual pool for reuse
     */
    public List<Pool> pools;
    public Dictionary<string, Queue<GameObject>> PoolDictionary;
    // Start is called before the first frame update
    void Start()
    {
        PoolDictionary = new Dictionary<string, Queue<GameObject>>();

        foreach (Pool pool in pools)
        {
            Queue<GameObject> objectPool = new Queue<GameObject>();

            for (int i = 0; i < pool.size; i++)
            {
                GameObject obj = Instantiate(pool.prefab);
                obj.SetActive(false);
                objectPool.Enqueue(obj);
            }

            PoolDictionary.Add(pool.tag, objectPool);
        }
    }

    //Requests object from pool, object reference returned for modification
    //Finds the correct pool from dictionary then dequeues from that pool, reenques to move it to the back of the queue for reuse
    public GameObject SpawnFromPool(string tag, Vector2 position, Quaternion rotation)
    {
        GameObject objectToSpawn = PoolDictionary[tag].Dequeue();

        objectToSpawn.SetActive(true);
        objectToSpawn.transform.position = position;
        objectToSpawn.transform.rotation = rotation;
        PoolDictionary[tag].Enqueue(objectToSpawn);

        return objectToSpawn;

    }

    //Return a count of how many of a specified object type are active in the scene
    public int GetActiveObjectsInPool(string tag)
    {
        int count = 0;
        //Access the object type's pool through dictionary lookup
        Queue<GameObject> objectPool = PoolDictionary[tag];
        foreach (GameObject obj in objectPool) 
        {
            if (obj.activeInHierarchy == true)
            {
                count++;
            } 
        }
        return count;
    }

}
