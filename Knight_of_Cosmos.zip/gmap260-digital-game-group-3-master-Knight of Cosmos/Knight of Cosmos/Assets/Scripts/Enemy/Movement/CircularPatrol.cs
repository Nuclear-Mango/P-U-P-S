﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CircularPatrol : MonoBehaviour, IMoveable
{
    public float radius = 1.5f;
    public float RotateSpeed = 1.5f;
    private int x;
    private int y;
    private Vector2 center;
    private float angle;

    // Update is called once per frame

    void Start()
    {
        x = Random.Range(0, 2) * 2 - 1;
        y = Random.Range(0, 2) * 2 - 1;
        center = new Vector2(x, y);
        center = transform.position;
    }

    void Update()
    {
        Move();

    }


    public void Move()
    {
        angle += RotateSpeed * Time.deltaTime;
        var offset = new Vector2(Mathf.Sin(angle), Mathf.Cos(angle) * radius);
        transform.position = center + offset;
    }

    public void RemoveComponent()
    {
        Destroy(this);
    }
}
