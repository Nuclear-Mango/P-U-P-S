﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeftRight : MonoBehaviour, IMoveable
{
    private Vector2 MovingDirection = Vector2.left;
    // Update is called once per frame
    void Update()
    {
        Move();
    }

    public void Move()
    {
        if (transform.position.x > 5.5f)
        {
            MovingDirection = Vector2.left;
        }
        else if (transform.position.x < 1.0f)
        {
            MovingDirection = Vector2.right;
        }
        transform.Translate(MovingDirection * Time.smoothDeltaTime);
    }

    public void RemoveComponent()
    {
        Destroy(this);
    }
}
