﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiagonalPatrol : MonoBehaviour, IMoveable
{
    private Vector2 MovingDirection;
    private int x;
    private int y;
    // Start is called before the first frame update
    void Start()
    {
        x = Random.Range(0, 2) * 2 - 1;
        y = Random.Range(0, 2) * 2 - 1;
        MovingDirection = new Vector2(x, y);
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    public void Move()
    {
        if (transform.position.x > 5.5f || transform.position.y > 2.75f || transform.position.y < -4.25f || transform.position.x < 1.5f)
        {
            x *= -1;
            y *= -1;
            MovingDirection = new Vector2(x, y);
        }
        transform.Translate(MovingDirection * Time.smoothDeltaTime * 0.75f);


    }

    public void RemoveComponent()
    {
        Destroy(this);
    }
}
