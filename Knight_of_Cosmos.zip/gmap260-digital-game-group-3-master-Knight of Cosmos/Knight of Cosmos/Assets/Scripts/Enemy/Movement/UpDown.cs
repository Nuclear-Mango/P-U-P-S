﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpDown : MonoBehaviour, IMoveable
{
    private Vector2 MovingDirection = Vector2.up;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    public void Move()
    {
        if (transform.position.y > 2.75f)
        {
            MovingDirection = Vector2.down;
        }
        else if (transform.position.y < -4.25f)
        {
            MovingDirection = Vector2.up;
        }
        transform.Translate(MovingDirection * Time.smoothDeltaTime);
    }

    public void RemoveComponent()
    {
        Destroy(this);
    }
}
