﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxPatrol : MonoBehaviour, IMoveable
{
    public int state = 3;
    private Vector2 MovingDirection = Vector2.down;
    // Update is called once per frame
    void Update()
    {
        Move();
    }

    public void Move()
    {
        //x =(1.0, 5.5) y =(-4.25, 2.75)
        if (transform.position.y < -4.25 && state == 3)
        {
            MovingDirection = Vector2.left;
            state = 0;
        }
        else if (transform.position.x < 1.0 && state == 0)
        {
            MovingDirection = Vector2.up;
            state = 1;
        }
        else if (transform.position.y > 2.75f && state == 1)
        {
            MovingDirection = Vector2.right;
            state = 2;
        }
        else if (transform.position.x > 5.5f && state == 2)
        {
            MovingDirection = Vector2.down;
            state = 3;
        }
        transform.Translate(MovingDirection * Time.smoothDeltaTime);
    }
    public void RemoveComponent()
    {
        Destroy(this);
    }
}
