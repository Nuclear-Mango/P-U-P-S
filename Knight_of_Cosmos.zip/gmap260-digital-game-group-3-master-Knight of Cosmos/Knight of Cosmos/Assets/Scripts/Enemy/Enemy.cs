﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Base class for inheritable enemy behavior
public class Enemy : MonoBehaviour, IDamageable
{
    protected int _maxHealth;
    protected int _health;
    protected float _fireInterval;
    protected IMoveable movement;
    protected IShootable attack;
    protected Vector2 moveVelocity;
    protected Animator enemyAnim;
    protected AudioSource enemySound;
    protected bool defeated;

    protected virtual void Awake()
    {
        enemyAnim = GetComponent<Animator>();
        enemySound = GetComponent<AudioSource>();
    }

    public void Initialize(int health, float fireInterval, string movementType, string attackPattern)
    {
        _maxHealth = health;
        _health = _maxHealth;
        _fireInterval = fireInterval;
        defeated = false;

        /* Enemy movement and attack pattern is customizable via switch statement
         * The string will be passed in from a spawner and it adds the corresponding component
         * This method is plainly hard coded but it suffices for a conditional component addition
         * Every additional script requires another addition to the switch is the downside 
         * For an unrecognized string, the enemy will remain stationary and/or not fire
        */
        switch (movementType)
        {
            case "UpDown":
                gameObject.AddComponent<UpDown>();
                break;
            case "LeftRight":
                gameObject.AddComponent<LeftRight>();
                break;
            case "BoxPatrol":
                gameObject.AddComponent<BoxPatrol>();
                break;
            case "CircularPatrol":
                gameObject.AddComponent<CircularPatrol>();
                break;
            case "DiagonalPatrol":
                gameObject.AddComponent<DiagonalPatrol>();
                break;
            default:
                break;
        }

        switch (attackPattern)
        {
            case "MultiSpread":
                gameObject.AddComponent<MultiSpread>();
                break;
            case "SingleLinear":
                gameObject.AddComponent<SingleLinear>();
                break;
            case "SingleAimed":
                gameObject.AddComponent<SingleAimed>();
                break;
            default:
                break;

        }
        attack = gameObject.GetComponent<IShootable>();
        movement = gameObject.GetComponent<IMoveable>();
    }

    //Override availability is specifically for the "Blastotron" enemy
    public virtual void TakeDamage(int amount)
    {
        if (!defeated)
        {
            _health -= amount;
            //defeated checked so the death animation will only trigger once in a frame
            if (_health <= 0)
            {
                defeated = true;
                Disable();
                Die();
            }
            else
            {
                enemyAnim.SetTrigger("Hurt");
            }
        }
        
    }

    public void Disable()
    {
        //Remove the movement and attack scripts so the enemy can be recycled and reinitialized properly
        if (movement != null)
        {
            movement.RemoveComponent();
        }
        if (attack != null)
        {
            attack.RemoveComponent();
        }
    }

    //Wrapper function to meet IDamageable's requirements - Interfaces can't define coroutines
    public void Die()
    {
        StartCoroutine("DeathEvent");
    }

    //Waits for the death animation to finish before deactivating the enemy
    public IEnumerator DeathEvent()
    {
        enemyAnim.SetTrigger("Dead");
        GetComponent<AudioSource>().Play();
        yield return new WaitForSeconds(0.5f);
        //Safety assignment to make sure health resets
        _health = _maxHealth;
        //Potentially drop a pick-up for the player on defeat
        PowerUpSpawn();
        gameObject.SetActive(false);
    }

    //Selects between either a medkit or sword power up, 10% chance for either of them to actually spawn when selected
    protected void PowerUpSpawn()
    {
        int pupIndex = Random.Range(0, 2);
        if (pupIndex == 0)
        {
            int medkitRN = Random.Range(0, 10);
            if (medkitRN == 0)
            {
                EnemyObjectPool.Instance.SpawnFromPool("Medkit", transform.position, Quaternion.identity);
            }
        }
        else
        {
            int swordRN = Random.Range(0, 10);
            if (swordRN == 0)
            {
                EnemyObjectPool.Instance.SpawnFromPool("SwordPowerUp", transform.position, Quaternion.identity);
            }
        }

    }
}
