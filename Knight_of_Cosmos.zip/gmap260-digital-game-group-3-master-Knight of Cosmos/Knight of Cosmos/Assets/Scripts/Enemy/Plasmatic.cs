﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plasmatic : Enemy, IPooledObject
{
    
    public void OnObjectSpawn()
    {
        //Call function of given attack pattern through interface
        //Movement is automatic in the move pattern's update function so it doesn't need to be called here
        //Fire rate variation keeps identical enemy types from firing at the same time
        float fireVariance = Random.Range(_fireInterval - 0.25f, _fireInterval + 0.25f);
        attack.InitiateAttack("Plasma", fireVariance);
    }

    
}
