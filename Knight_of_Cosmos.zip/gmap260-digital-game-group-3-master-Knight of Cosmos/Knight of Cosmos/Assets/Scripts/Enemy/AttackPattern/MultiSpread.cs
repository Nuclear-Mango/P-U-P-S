﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiSpread : MonoBehaviour, IShootable, IAdditive
{
    private string projectileType;
    private int projectileAmount;
    private float cooldown;

    private float startAngle = 240f;
    private float endAngle = 330f;
    public void InitiateAttack(string projectile, float fireInterval)
    {
        projectileType = projectile;
        cooldown = fireInterval;
        //Bullet amount based off wave scaling
        projectileAmount = 3 + WaveManager.Instance.ShotBonus;
        Invoke("Fire", 2f);
    }

    public void Fire()
    {
        StartCoroutine("FirePattern");
    }

    public IEnumerator FirePattern()
    {
        while (true)
        {
            //Delay firing via sanity check on projectiles present
            yield return new WaitWhile(() => EnemyObjectPool.Instance.GetActiveObjectsInPool(projectileType) + projectileAmount > 12);

            float angleStep = (endAngle - startAngle) / projectileAmount;
            float angle = startAngle;
            //Request multiple bullets from the pool and gives them different direction offsets
            for (int i = 0; i < projectileAmount; i++)
            {
                //Determine offset direction through trigonometry
                float bulletDirectionX = transform.position.x + Mathf.Sin((angle * Mathf.PI) / 180f);
                float bulletDirectionY = transform.position.y + Mathf.Cos((angle * Mathf.PI) / 180f);

                Vector3 bulletMoveVector = new Vector3(bulletDirectionX, bulletDirectionY, 0f);
                Vector2 bulletDirection = (bulletMoveVector - transform.position).normalized;

                GameObject bulletObj = EnemyObjectPool.Instance.SpawnFromPool(projectileType, transform.position, Quaternion.identity);
                Bullet bulletData = bulletObj.GetComponent<Bullet>();
                //Bullet will move in offset direction
                bulletData.MoveDirection = bulletDirection;
                bulletData.Source = gameObject;

                //Begin enemy behavior
                IPooledObject pooledObj = bulletObj.GetComponent<IPooledObject>();
                if (pooledObj != null)
                {
                    pooledObj.OnObjectSpawn();
                }

                angle += angleStep;
            }
            yield return new WaitForSeconds(cooldown);
        }
    } 

    public void RemoveComponent()
    {
        Destroy(this);
    }

    //Currently unused but not deemed useless
    public void IncrementTotal()
    {
        projectileAmount++;
    }
}
