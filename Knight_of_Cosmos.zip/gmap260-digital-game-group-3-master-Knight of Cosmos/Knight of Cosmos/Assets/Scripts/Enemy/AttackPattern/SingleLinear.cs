﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleLinear : MonoBehaviour, IShootable
{
    private string projectileType;
    public void InitiateAttack(string projectile, float fireInterval)
    {
        projectileType = projectile;
        InvokeRepeating("Fire", 1f, fireInterval);
    }

    public void Fire()
    {
        //Request single projectile from pool and set initial data
        GameObject bulletObj = EnemyObjectPool.Instance.SpawnFromPool(projectileType, transform.position, Quaternion.identity);
        Bullet bulletData = bulletObj.GetComponent<Bullet>();
        //Bullet will move linearly
        bulletData.MoveDirection = Vector2.left;
        bulletData.Source = gameObject;
        
        //Begin enemy behavior
        IPooledObject pooledObj = bulletObj.GetComponent<IPooledObject>();
        if (pooledObj != null)
        {
            pooledObj.OnObjectSpawn();
        }
    }

    public void RemoveComponent()
    {
        Destroy(this);
    }
    
}
