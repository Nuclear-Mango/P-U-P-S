﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleAimed : MonoBehaviour, IShootable
{
    private string projectileType;
    public void InitiateAttack(string projectile, float fireInterval)
    {
        projectileType = projectile;
        InvokeRepeating("Fire", 1.5f, fireInterval);
    }

    public void Fire()
    {
        //Request single projectile from pool and set initial data
        GameObject bulletObj = EnemyObjectPool.Instance.SpawnFromPool(projectileType, transform.position, Quaternion.identity);
        Bullet bulletData = bulletObj.GetComponent<Bullet>();
        //Bullet will move toward player's last calculated direction
        Vector2 playerDirection = GameObject.FindGameObjectWithTag("Player").transform.position - transform.position;
        bulletData.MoveDirection = playerDirection.normalized;
        bulletData.Source = gameObject;

        //Begin enemy behavior
        IPooledObject pooledObj = bulletObj.GetComponent<IPooledObject>();
        if (pooledObj != null)
        {
            pooledObj.OnObjectSpawn();
        }
    }

    public void RemoveComponent()
    {
        Destroy(this);
    }
}
