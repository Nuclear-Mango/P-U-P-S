﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blastotron : Enemy, IPooledObject, IKamikaze
{
    private bool kamikaze;
    private bool initialized = false;
    private bool stunned;
    private GameObject player;
    private SpriteRenderer rdr;
    private float kamikazeTimer;
    private float kamikazeTime;
    private int startingEnemyCount;
    private bool enemiesSurveyed;

    
    protected override void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        rdr = GetComponent<SpriteRenderer>();
        enemyAnim = GetComponent<Animator>();
        enemySound = GetComponent<AudioSource>();
    }

    public void OnObjectSpawn()
    {
        //Call function of given attack pattern through interface
        //Movement is automatic in the move pattern's update function so it doesn't need to be called here
        //Blastotron fires at 1/3 the rate of Plasmatic as bombs are the most threatening projectile
        float fireVariance = Random.Range(_fireInterval - 0.25f, _fireInterval + 0.25f);
        attack.InitiateAttack("Bomb", fireVariance * 3.0f);
        kamikazeTimer = 0f;
        kamikazeTime = Random.Range(25f, 40f);
        enemiesSurveyed = false;
        StartCoroutine("InitialEnemyCount");
        initialized = true;
    }

    private void Update()
    {
        if (initialized)
        {
            if (!kamikaze && enemiesSurveyed)
            {
                kamikazeTimer += Time.deltaTime;
                //Check if non-Blastotron enemies are present before switching modes
                int otherEnemyCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Plasmatic") + EnemyObjectPool.Instance.GetActiveObjectsInPool("Beemius");
                //Switch modes if there are no other enemies or the Blastotron has been alive for 30 seconds
                //Also check that more than just Blastotrons spawned to begin with, basically giving the player a round to only dodge bombs otherwise
                if ((otherEnemyCount == 0 && startingEnemyCount != 0) || kamikazeTimer >= kamikazeTime)
                {
                    kamikaze = true;
                    
                    attack.RemoveComponent();
                    movement.RemoveComponent();
                }
            }
            else if (!stunned)
            {
                //Face the player's general direction
                if (transform.position.x - player.transform.position.x < 0 )
                {
                    rdr.flipX = true;
                }
                else
                {
                    rdr.flipX = false;
                }
                //Drop everything, stop shooting, and home in on the player furiously in kamikaze mode
                transform.position = Vector2.MoveTowards(transform.position, player.transform.position, 3.25f * Time.deltaTime);
            }
            
        }
    }

    public override void TakeDamage(int amount)
    {
        if (!defeated)
        {
            _health -= amount;
            //defeated checked so the death animation will only trigger once in a frame
            if (_health <= 0)
            {
                defeated = true;
                stunned = false;
                Disable();
                Die();
            }
            else
            {
                enemyAnim.SetTrigger("Hurt");
                if (!stunned && kamikaze)
                {
                    StartCoroutine("Stunned");
                }
            }
        }
       
    }

    private void OnDisable()
    {
        initialized = false;
        kamikaze = false;
        rdr.flipX = false;
    }

    public IEnumerator Stunned()
    {
        stunned = true;
        //Knock the enemy backward on stun
        if (!rdr.flipX)
        {
            transform.position = new Vector2(transform.position.x + 1f, transform.position.y);
        }
        else
        {
            //Prevent the enemy from going off screen from knockback
            if (transform.position.x - 1f > -6f)
            {
                transform.position = new Vector2(transform.position.x - 2f, transform.position.y);
            }
            
        }
        yield return new WaitForSeconds(0.5f);
        stunned = false;
    }

    public bool isBerserk()
    {
        return kamikaze;
    }

    IEnumerator InitialEnemyCount()
    {
        //Allot a small time window for every enemy to spawn before gathering enemy count
        yield return new WaitForSeconds(0.25f);
        startingEnemyCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Plasmatic") + EnemyObjectPool.Instance.GetActiveObjectsInPool("Beemius");
        enemiesSurveyed = true;

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            IDamageable damagedPlayer = collision.GetComponent<IDamageable>();
            if (damagedPlayer != null)
            {
                damagedPlayer.TakeDamage(1);
            }
        }
    }
}
