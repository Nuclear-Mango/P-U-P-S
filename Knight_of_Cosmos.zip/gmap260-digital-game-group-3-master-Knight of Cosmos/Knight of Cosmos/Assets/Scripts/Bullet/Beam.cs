﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Beam : Bullet, IPooledObject, IBlockable
{
    public void OnObjectSpawn()
    {
        Speed = 8f;
        Initialized = true;
    }

    void Update()
    {
        //Make sure the beam is properly spawned before initiating behavior
        if (Initialized)
        {
            //Checks if the projectile is still within the bounds of the gameplay field
            if (transform.position.x >= 7.5f || transform.position.x <= -7.5f || transform.position.y >= 6.0f || transform.position.y <= -6.0f)
            {
                gameObject.SetActive(false);
            }

            transform.Translate(MoveDirection * Speed * Time.deltaTime);
        }
    }

    //TODO: Add logic to make the beam add to the shield meter when player blocks it
    public void Absorb()
    {
        gameObject.SetActive(false);
    }
}
