﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plasma : Bullet, IDeflectable, IPooledObject
{
    private bool isDeflected;
    private SpriteRenderer rdr;
    private bool isHoming;
    private AudioSource deflectSound;
    private void Awake()
    {
        rdr = GetComponent<SpriteRenderer>();
        deflectSound = GetComponent<AudioSource>();
    }
    public void OnObjectSpawn()
    {
        Speed = 6f;
        isDeflected = false;
        isHoming = false;
        Initialized = true;
        rdr.flipX = false;
    }

    void Update()
    {
        //Make sure the plasma is properly spawned before initiating behavior
        if (Initialized)
        {
            //Checks if the projectile is still within the bounds of the gameplay field
            if (transform.position.x >= 7.5f || transform.position.x <= -7.5f || transform.position.y >= 6.0f || transform.position.y <= -6.0f)
            {
                gameObject.SetActive(false);
            }
            if (!isHoming)
            {
                transform.Translate(MoveDirection * Speed * Time.deltaTime);
            }
            else
            {
                //Check to make sure target is still alive, otherwise transition to normal deflection behavior mid flight
                if (Source.activeInHierarchy)
                {
                    transform.position = Vector2.MoveTowards(transform.position, Source.transform.position, Speed * Time.deltaTime);
                }
                else
                {
                    isHoming = false;
                    MoveDirection *= -1;
                }
                
            }
            
        }
    }

    //Reverses plasma direction through its speed and sets flag
    public void Deflect()
    {
        if (!isDeflected)
        {
            isDeflected = true;
            MoveDirection *= -1;
            rdr.flipX = true;
            deflectSound.Play();
        }
        
    }

    //Homes in on enemy who shot the bullet after deflection if they are still active
    public void HomingDeflect()
    {
        if (Source.activeInHierarchy)
        {
            isDeflected = true;
            isHoming = true;
            rdr.flipX = true;
            deflectSound.Play();
        }
        else
        {
            //Normally deflect the shot if the enemy is defeated before the bullet is hit
            Deflect();
        }
        
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && !isDeflected)
        {
            IDamageable playerObj = collision.GetComponent<IDamageable>();
            playerObj.TakeDamage(1);
            gameObject.SetActive(false);
        }
        else if (!collision.gameObject.CompareTag("Player") && isDeflected)
        {
            IDamageable enemyObj = collision.GetComponent<IDamageable>();
            if (enemyObj != null)
            {
                enemyObj.TakeDamage(1);
                gameObject.SetActive(false);
            }
        }
    }


}
