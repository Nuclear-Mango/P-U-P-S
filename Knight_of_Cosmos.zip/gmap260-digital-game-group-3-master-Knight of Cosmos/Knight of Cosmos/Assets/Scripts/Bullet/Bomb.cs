﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : Bullet, IPooledObject, IExplode
{

    private Animator detonator;
    private bool detonated;
    private AudioSource boomSound;

    public void OnObjectSpawn()
    {
        Speed = 3f;
        detonated = false;
        Initialized = true;
    }

    void Awake()
    {
        detonator = GetComponent<Animator>();
        boomSound = GetComponent<AudioSource>();
    }

    void Update()
    {
        //Make sure the bomb is properly spawned before initiating behavior
        if (Initialized)
        {
            //Checks if the projectile is still within the bounds of the gameplay field
            if (transform.position.x >= 7.5f || transform.position.x <= -7.5f || transform.position.y >= 6.0f || transform.position.y <= -6.0f)
            {
                gameObject.SetActive(false);
            }

            transform.Translate(MoveDirection * Speed * Time.deltaTime);
        }
    }

    //Wrapper function for triggering bomb explosion through interface
    public void Boom()
    {
        detonated = true;
        StartCoroutine("Explosion");
    }

    IEnumerator Explosion()
    {
        detonator.SetTrigger("Explode");
        boomSound.Play();
        yield return new WaitForSeconds(0.5f);
        gameObject.SetActive(false);
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            //Explode on player collision
            if (!detonated)
            {
                Boom();
            }
            IDamageable playerObj = collision.GetComponent<IDamageable>();
            playerObj.TakeDamage(1);
        }
    }
}
