﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Base class for projectiles to inherit data from
public class Bullet : MonoBehaviour, IClearable
{
    //Create private fields for the bullet's movement with public getters and setters
    public float Speed { get; set; }
    public Vector2 MoveDirection { get; set; }
    //Source keeps track of the entity that shot the bullet
    public GameObject Source { get; set; }
    public bool Initialized { get; set; }

    protected virtual void OnDisable()
    {
        Initialized = false;
    }
    //Damage player and disable projectile for base behavior
    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            IDamageable playerObj = collision.GetComponent<IDamageable>();
            playerObj.TakeDamage(1);
            gameObject.SetActive(false);
        }
    }

    public void Clear()
    {
        //Intentionally left blank
    }



}
