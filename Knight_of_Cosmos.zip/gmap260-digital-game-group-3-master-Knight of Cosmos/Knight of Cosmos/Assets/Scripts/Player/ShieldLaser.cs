﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldLaser : MonoBehaviour
{
    
    //Shield laser does heavy damage to enemies while clearing bullets in its path
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Player"))
        {
            IDamageable damagedObj = collision.GetComponent<IDamageable>();
            if (damagedObj != null)
            {
                damagedObj.TakeDamage(3);
                
                return;
            }

            IClearable clearedObj = collision.GetComponent<IClearable>();
            if (clearedObj != null)
            {
                collision.gameObject.SetActive(false);
            }
        }
        
    }   
        
    
}
