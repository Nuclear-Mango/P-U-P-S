﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHUD : MonoBehaviour
{
    public int maxHealth = 3;
    public int currentHealth;
    public int maxSword = 3;
    public int currentSword;
    public int maxShield = 3;
    public int currentShield;
    public HealthBar healthBar;
    public HealthBar swordBar;
    public HealthBar shieldBar;

    private bool isPoweredUp;
    private float powerUpTimer;

    private static PlayerHUD _instance;
    public static PlayerHUD Instance
    {
        get
        {
            if (_instance == null)
            {
                Debug.LogError("Null player HUD");
            }
            return _instance;
        }
    }

    private void Awake()
    {
        _instance = this;
        //sword charge and shield charge start at 0 while Health will start at Max Health at the beginning of the game
        currentHealth = maxHealth;
        currentSword = 0;
        currentShield = 0;
        isPoweredUp = false;
        powerUpTimer = 0f;
        //initializes the UI Health/Sword/Shield bars
        healthBar.SetMaxHealth(maxHealth);
        swordBar.SetMaxHealth(maxSword, currentSword);
        shieldBar.SetMaxHealth(maxShield, currentShield);
    }

    //Manage timer for power up
    private void Update()
    {
        if (isPoweredUp)
        {
            if (powerUpTimer < 10f)
            {
                powerUpTimer += Time.deltaTime;
            }
            else
            {
                isPoweredUp = false;
                powerUpTimer = 0f;
            }
        }
    }
    public void ChargeSword()
    {
        if (!isPoweredUp)
        {
            //increments sword charge
            currentSword += 1;
            //if sword charge is full and you reflect another projectile then it sets it back to 0
            if (currentSword > 3)
            {
                ResetSword();
            }
            else
            {
                //this updates the UI Sword Bar
                swordBar.SetHealth(currentSword);
            }
        }
    }

    public void ChargeShield()
    {
        
        //increments shield charge
        if (currentShield < 3)
        {
            currentShield += 1;
        }
        //this updates the UI Shield Bar
        shieldBar.SetHealth(currentShield);
    }

    public void ResetSword()
    {
        if (!isPoweredUp)
        {
            currentSword = 0;
            swordBar.SetHealth(currentSword);
        }
        
    }

    public void ResetShield()
    {
        currentShield = 0;
        shieldBar.SetHealth(currentShield);
    }

    //Referenced by medkit
    public void Heal()
    {
        if (currentHealth != 3)
        {
            currentHealth++;
        }
        healthBar.SetHealth(currentHealth);
    }

    //Enters a state of infinite deflection ability for 10 seconds
    //Sword meter will not budge from 3 for the duration
    public void PowerUpSword()
    {
        if (!isPoweredUp)
        {
            currentSword = 3;
            swordBar.SetHealth(currentSword);
            isPoweredUp = true;
        }
        //Reset the timer if another one is picked up before it ends
        else
        {
            powerUpTimer = 0f;
        }
        
    }
}
