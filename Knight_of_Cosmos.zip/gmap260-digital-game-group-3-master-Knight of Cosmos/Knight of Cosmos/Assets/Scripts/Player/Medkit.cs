﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Simple health pickup that calls to update the HUD value and display when the player collides with it
public class Medkit : MonoBehaviour
{
    private float speed = 3f;
    private AudioSource healSound;
    private SpriteRenderer rdr;
    private BoxCollider2D medkitCollider;


    private void Awake()
    {
        healSound = GetComponent<AudioSource>();
        rdr = GetComponent<SpriteRenderer>();
        medkitCollider = GetComponent<BoxCollider2D>();
    }
    // Update is called once per frame
    void Update()
    {
        //Move left toward the player's general direction
        if (transform.position.x > -7f)
        {
            transform.Translate(Vector2.left * speed * Time.deltaTime);
        }
        else
        {
            gameObject.SetActive(false);
        }
       
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            StartCoroutine("HealPickup");
        }
    }

    IEnumerator HealPickup()
    {
        medkitCollider.enabled = false;
        rdr.enabled = false;
        PlayerHUD.Instance.Heal();
        healSound.Play();
        yield return new WaitForSeconds(1.25f);
        gameObject.SetActive(false);
    }

    private void OnDisable()
    {
        rdr.enabled = true;
        medkitCollider.enabled = true;
    }
}
