﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour, IDamageable
{
    public float speed = 6f;
    private Vector2 moveVelocity;
    private Animator Orion;
    public float shieldRange = 1f;
    public GameOver gameOver;
    private bool attacking = false;
    private float attackTimer = 0;
    private float attackCooldown = 0.4f;
    private PlayerHUD HUD;
    private bool attackHit;
    public GameObject Weapon;
    public GameObject Laser;
    private BoxCollider2D swordHitBox;
    private AudioSource laserSound;
    private AudioSource swordSound;
    private AudioSource deathSound;
    private ContactFilter2D validTargets;
    private bool defeated = false;
    private bool damaged = false;
    public SpriteRenderer rdr;
    public bool altControls;

    void Awake()
    {
        Orion = GetComponent<Animator>();
        Orion.SetBool("Shielding", false);
        Orion.SetBool("Attacking", false);
        Time.timeScale = 1f;
        PauseMenu.GameIsPaused = false;
        attackHit = false;
        swordHitBox = Weapon.GetComponent<BoxCollider2D>();
        laserSound = Laser.GetComponent<AudioSource>();
        swordSound = Weapon.GetComponent<AudioSource>();
        deathSound = GetComponent<AudioSource>();
        //This filters out all objects except for entities the sword can damage/deflect
        validTargets.SetLayerMask(LayerMask.GetMask("Attackable"));
        validTargets.useTriggers = true;
        validTargets.useLayerMask = true;
        altControls = true;
    }

    void Start()
    {
        HUD = PlayerHUD.Instance;
        altControls = AltControls.altControls;
    }

    void Update()
    {
        if (HUD.currentHealth > 0)
        {
            Move();
            //Disable attack/shield while scene transitions
            if (!Orion.GetCurrentAnimatorStateInfo(0).IsName("Onward"))
            {
                Attack();
                Shield();
            }
            
        }
        else
        {
            if (!defeated)
            {
                defeated = true;
                Die();
            }

        }
        altControls = AltControls.altControls;

    }

    void Attack()
    {
        if (!altControls)
        {
            
            if (Input.GetKeyDown(KeyCode.Z) && !Orion.GetBool("Shielding") && !attacking)
            {
                attacking = true;
                attackTimer = attackCooldown;
                swordSound.Play();
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.J) && !Orion.GetBool("Shielding") && !attacking)
            {
                attacking = true;
                attackTimer = attackCooldown;
                swordSound.Play();
            }
        }
        
        if (attacking)
        {
            if (attackTimer > 0)
            {
                attackTimer -= Time.deltaTime;
                //Used to determine if an attack lands for the combo mechanic
                int HitDetection = swordHitBox.OverlapCollider(validTargets, new Collider2D[1]);
                if (HitDetection > 0)
                {
                    attackHit = true;
                }
            }
            else
            {
                attacking = false;
                //Reset the sword meter on whiff, breaking the combo
                if (!attackHit)
                {
                    HUD.ResetSword();
                }
                else
                {
                    //Reset the check, leave the sword meter alone
                    attackHit = false;
                }
            }
        }

        Orion.SetBool("Attacking", attacking);
    }

    void Shield()
    {
        if (!altControls)
        {
            if (Input.GetKey(KeyCode.X) && !Orion.GetCurrentAnimatorStateInfo(0).IsName("ShieldDown"))
            {
                Orion.SetBool("Shielding", true);
                Collider2D[] ShieldDetection = Physics2D.OverlapCircleAll(transform.position, shieldRange);
                for (int i = 0; i < ShieldDetection.Length; i++)
                {
                    IBlockable blockedObj = ShieldDetection[i].GetComponent<IBlockable>();
                    if (blockedObj != null)
                    {
                        HUD.ChargeShield();
                        blockedObj.Absorb();
                    }
                }
            }
            if (Input.GetKeyUp(KeyCode.X))
            {
                Orion.SetInteger("ShieldCharge", HUD.currentShield);
                Orion.SetBool("Shielding", false);
                if (HUD.currentShield == 3)
                {
                    laserSound.Play();
                }
                HUD.ResetShield();
            }
        }
        else {
            if (Input.GetKey(KeyCode.K) && !Orion.GetCurrentAnimatorStateInfo(0).IsName("ShieldDown"))
            {
                Orion.SetBool("Shielding", true);
                Collider2D[] ShieldDetection = Physics2D.OverlapCircleAll(transform.position, shieldRange);
                for (int i = 0; i < ShieldDetection.Length; i++)
                {
                    IBlockable blockedObj = ShieldDetection[i].GetComponent<IBlockable>();
                    if (blockedObj != null)
                    {
                        HUD.ChargeShield();
                        blockedObj.Absorb();
                    }
                }
            }
            if (Input.GetKeyUp(KeyCode.K))
            {
                Orion.SetInteger("ShieldCharge", HUD.currentShield);
                Orion.SetBool("Shielding", false);
                if (HUD.currentShield == 3)
                {
                    laserSound.Play();
                }
                HUD.ResetShield();
            }
        }

        
    }

    void Move()
    {
        int xVel = 0;
        int yVel = 0;

        if (!altControls)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                yVel = 1;
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                yVel = -1;
            }

            if (Input.GetKey(KeyCode.RightArrow))
            {
                xVel = 1;
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                xVel = -1;
            }
        }
        else
        {
            if (Input.GetKey(KeyCode.W))
            {
                yVel = 1;
            }
            else if (Input.GetKey(KeyCode.S))
            {
                yVel = -1;
            }

            if (Input.GetKey(KeyCode.D))
            {
                xVel = 1;
            }
            else if (Input.GetKey(KeyCode.A))
            {
                xVel = -1;
            }
        }
        Vector2 moveInput = new Vector2(xVel, yVel);
        moveVelocity = moveInput.normalized * speed;

        if (xVel != 0 || yVel != 0)
        {
            if (!AtBoundary(new Vector2(transform.position.x, transform.position.y) + moveVelocity * Time.deltaTime))
            {

                if (!Orion.GetBool("Shielding"))
                {
                    transform.Translate(moveVelocity * Time.deltaTime);
                }
                else
                {
                    transform.Translate(moveVelocity * Time.deltaTime * 0.5f);
                }

            }
        }
    }

    //call this function whenever the player takes damage
    public void TakeDamage(int damage)
    {
        //Checks if the player is in damage invulnerability period
        if (!damaged)
        {
            //Makes the player take damage
            HUD.currentHealth -= damage;
            //this updates the UI Health Bar
            HUD.healthBar.SetHealth(HUD.currentHealth);
            if (HUD.currentHealth > 0)
            {
                damaged = true;
                StartCoroutine("DamageBlink");
            }
        }

    }

    //Check if the player's next movement would break predefined gameplay field bounds
    bool AtBoundary(Vector2 calculatedPosition)
    {
        float minY = -4.5f;
        float maxY = 3.0f;
        float minX = -6f;
        float maxX = 0f;

        if (calculatedPosition.x >= maxX || calculatedPosition.x <= minX || calculatedPosition.y >= maxY || calculatedPosition.y <= minY)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //Wrapper function to meet IDamageable's requirements - Interfaces can't define coroutines
    public void Die()
    {
        StartCoroutine("DeathEvent");
    }

    //Waits for the death animation to finish before deactivating the enemy
    public IEnumerator DeathEvent()
    {
        Orion.SetTrigger("Dead");
        deathSound.Play();
        yield return new WaitForSeconds(1f);
        gameOver.gameOverScreen();
    }

    //Grants temporary invincibility after being damaged, indicated by blinking sprite
    public IEnumerator DamageBlink()
    {
        Color c = rdr.color;

        for (int i = 0; i < 8; i++)
        {
            c.a = 0.5f;
            rdr.color = c;
            yield return new WaitForSeconds(0.1f);
            c.a = 1f;
            rdr.color = c;
            yield return new WaitForSeconds(0.1f);
        }

        damaged = false;
    }
    public void SetAltControls(bool thing)
    {
        altControls = thing;
    }


}

