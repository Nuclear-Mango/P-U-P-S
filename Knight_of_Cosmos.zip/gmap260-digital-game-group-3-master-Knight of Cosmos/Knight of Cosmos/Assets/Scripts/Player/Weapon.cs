﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Manages the sword collision events when Orion attacks
public class Weapon : MonoBehaviour
{
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Only the blastotron can be harmed directly by the sword, and only when it is in kamikaze mode
        if (collision.CompareTag("Blastotron"))
        {
            IDamageable damagedObj = collision.GetComponent<IDamageable>();
            IKamikaze modeCheck = collision.GetComponent<IKamikaze>();
            if (damagedObj != null && modeCheck != null)
            {
                if (modeCheck.isBerserk())
                {
                    damagedObj.TakeDamage(2);
                    
                }
            }
        }
        
        else
        {
            IDeflectable deflectedObj = collision.GetComponent<IDeflectable>();
            if (deflectedObj != null)
            {

                //Head straight for the attacker if 3 swings have been landed
                if (PlayerHUD.Instance.currentSword == 3)
                {
                    deflectedObj.HomingDeflect();
                    
                }
                else
                {
                    deflectedObj.Deflect();
                    
                }
                PlayerHUD.Instance.ChargeSword();
                return;
            }
            //Check to see if it hit a bomb, explode on hit
            IExplode bombObj = collision.GetComponent<IExplode>();
            if (bombObj != null)
            {
                bombObj.Boom();
                return;
            }
            //Check for meteor hit
            IBreakable meteorObj = collision.GetComponent<IBreakable>();
            if (meteorObj != null)
            {
                meteorObj.Break();
                return;
            }
        }   
    }
}
