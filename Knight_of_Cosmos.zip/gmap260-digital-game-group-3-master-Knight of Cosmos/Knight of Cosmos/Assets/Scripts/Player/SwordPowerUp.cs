﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwordPowerUp : MonoBehaviour
{
    private float speed = 3f;
    private AudioSource pupSound;
    private SpriteRenderer rdr;
    private BoxCollider2D pupCollider;



    private void Awake()
    {
        pupSound = GetComponent<AudioSource>();
        rdr = GetComponent<SpriteRenderer>();
        pupCollider = GetComponent<BoxCollider2D>();
    }
    // Update is called once per frame
    void Update()
    {
        //Move left toward the player's general direction
        if (transform.position.x > -7f)
        {
            transform.Translate(Vector2.left * speed * Time.deltaTime);
        }
        else
        {
            gameObject.SetActive(false);
        }

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            StartCoroutine("SwordPickUp");
        }
    }

    IEnumerator SwordPickUp()
    {
        pupCollider.enabled = false;
        rdr.enabled = false;
        PlayerHUD.Instance.PowerUpSword();
        pupSound.Play();
        yield return new WaitForSeconds(1.25f);
        gameObject.SetActive(false);
    }

    private void OnDisable()
    {
        pupCollider.enabled = true;
        rdr.enabled = true;
    }
}
