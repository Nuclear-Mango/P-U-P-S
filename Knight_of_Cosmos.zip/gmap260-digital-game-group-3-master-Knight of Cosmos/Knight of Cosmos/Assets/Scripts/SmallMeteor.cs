﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Smaller meteors spawned from big ones, will launch linearly at high speed and damage enemies
public class SmallMeteor : MonoBehaviour, IPooledObject
{
    private float speed = 5f;
    private bool Initialized = false;
    public Vector2 MoveDirection { get; set; }
    public void OnObjectSpawn()
    {
        Initialized = true;
    }
    
    // Update is called once per frame
    void Update()
    {
        if (Initialized)
        {
            //Return meteor to pool if it goes out of bounds
            if (transform.position.x < 7.5f && transform.position.y < 6f && transform.position.y > -6f)
            {
                transform.Translate(MoveDirection * speed * Time.deltaTime);
            }
            else
            {
                gameObject.SetActive(false);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Damage enemies on collision
        if (!collision.gameObject.CompareTag("Player"))
        {
            IDamageable hitEnemy = collision.GetComponent<IDamageable>();
            if (hitEnemy != null)
            {
                hitEnemy.TakeDamage(1);
                gameObject.SetActive(false);
            }
        }
    }

    private void OnDisable()
    {
        Initialized = false;
    }
}
