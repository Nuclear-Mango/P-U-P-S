﻿using UnityEngine;

//Interface to force implementation of a custom function for spawn behavior
//Used by: All enemies and projectiles
public interface IPooledObject
{
    void OnObjectSpawn();
}
