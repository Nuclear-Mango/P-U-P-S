﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Interface to let the bomb explode
public interface IExplode
{
    void Boom();
}
