﻿using UnityEngine;

//Interface to enforce implementation of damage calculations
//Used by: Player, any enemy object
public interface IDamageable 
{
    void TakeDamage(int amount);
    void Die();
}
