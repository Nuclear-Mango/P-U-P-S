﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Used specifically by Blastotron to check for kamikaze status
public interface IKamikaze
{
    bool isBerserk();
    
}
