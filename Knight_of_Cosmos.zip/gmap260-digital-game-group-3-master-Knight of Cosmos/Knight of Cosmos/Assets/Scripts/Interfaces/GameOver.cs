﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    public GameObject gameOverUI;
    // Update is called once per frame
    public void gameOverScreen()
    {
        gameOverUI.SetActive(true);
        Time.timeScale = 0f;
        PauseMenu.GameIsPaused = true;
        //stop main game BGM and swap to GameOver BGM if we have it
    }
    public void LoadMenu()
    {
        Time.timeScale = 1f;
        PauseMenu.GameIsPaused = false;
        gameOverUI.SetActive(false);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }
}
