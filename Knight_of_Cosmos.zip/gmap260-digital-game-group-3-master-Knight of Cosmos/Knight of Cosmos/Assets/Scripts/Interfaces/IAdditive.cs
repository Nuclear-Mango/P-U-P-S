﻿
using UnityEngine;

//Interface to force implementation of incrementing some total
//Used by: Any "Multi" attack pattern (for scaling purposes)
public interface IAdditive
{
    void IncrementTotal();
}
