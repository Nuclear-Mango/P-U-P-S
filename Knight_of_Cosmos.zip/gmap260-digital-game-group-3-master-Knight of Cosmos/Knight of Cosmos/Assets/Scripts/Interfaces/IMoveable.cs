﻿
using UnityEngine;

//Interface to force implementation of movement and runtime component removal
//Used by: All movement pattern scripts
public interface IMoveable
{
    void Move();

    void RemoveComponent();
}
