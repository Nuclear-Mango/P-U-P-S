﻿
using UnityEngine;

//Interface to force implementation of attack initialization and runtime component removal
//Used by: All attack pattern scripts
public interface IShootable
{
    void InitiateAttack(string projectile, float fireInterval);

    void RemoveComponent();
}
