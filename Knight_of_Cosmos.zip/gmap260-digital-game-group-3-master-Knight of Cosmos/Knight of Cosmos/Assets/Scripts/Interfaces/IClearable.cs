﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//The function here is useless, only used by laser to know if the entity is a bullet
public interface IClearable
{
    void Clear();
}
