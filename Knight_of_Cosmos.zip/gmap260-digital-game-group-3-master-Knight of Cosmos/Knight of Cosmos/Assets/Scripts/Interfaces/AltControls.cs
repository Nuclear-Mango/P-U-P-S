﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AltControls : MonoBehaviour
{
    public static bool altControls;

    public void SetAltControls(bool thing)
    {
        altControls = thing;
    }

}
