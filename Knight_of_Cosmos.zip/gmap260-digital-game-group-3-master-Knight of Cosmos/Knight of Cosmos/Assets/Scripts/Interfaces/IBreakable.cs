﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Used by BigMeteor to split into projectile pieces
public interface IBreakable
{
    void Break();
}
