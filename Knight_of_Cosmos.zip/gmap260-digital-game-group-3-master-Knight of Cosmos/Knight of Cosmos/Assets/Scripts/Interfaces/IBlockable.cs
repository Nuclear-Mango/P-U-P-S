﻿
using UnityEngine;

//Interface to enforce implementation of being absorbed
//Used by: Beam
public interface IBlockable 
{
    void Absorb();
}
