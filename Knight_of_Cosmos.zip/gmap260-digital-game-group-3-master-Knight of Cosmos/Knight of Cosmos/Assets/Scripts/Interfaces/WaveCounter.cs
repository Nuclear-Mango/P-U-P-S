﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class WaveCounter : MonoBehaviour
{
    public Text counter;
    public Text HighScore;
    public static int highScore = 0;
    // Update is called once per frame
    public void SetCounter(int w)
    {
        if (w > highScore)
        {
            highScore = w;
        }
        string s = "";
        s += w;
        counter.text = s;
        SetHighScore();
    }
    public void SetHighScore()
    {
        string m = "";
        m += highScore;
        HighScore.text = m;
    }
}
