﻿using UnityEngine;

//Interface to force implementation of being deflected
//Used by: Plasma
public interface IDeflectable
{
    void Deflect();
    void HomingDeflect();
}
