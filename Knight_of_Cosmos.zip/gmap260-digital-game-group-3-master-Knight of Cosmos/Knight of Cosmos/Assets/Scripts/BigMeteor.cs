﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigMeteor : MonoBehaviour, IPooledObject, IClearable, IBreakable
{
    public Vector2 spawnPoint { get; set; }
    private bool Initialized;
    private Vector2 moveDirection;
    private float speed;
    private bool broken = false;
    private AudioSource breakSound;
    private BoxCollider2D meteorCollider;
    private SpriteRenderer rdr;


    private void Awake()
    {
        breakSound = GetComponent<AudioSource>();
        meteorCollider = GetComponent<BoxCollider2D>();
        rdr = GetComponent<SpriteRenderer>();
    }
    public void OnObjectSpawn()
    {
        speed = 1.5f;
        //Move up or down based on spawn point
        if (spawnPoint.y < 0)
        {
            moveDirection = Vector2.up;
        }
        else
        {
            moveDirection = Vector2.down;
        }
        Initialized = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (Initialized && !broken)
        {
            //Return meteor to pool if it goes out of bounds
            if (transform.position.y < 6f && transform.position.y >= -6f)
            {
                transform.Translate(moveDirection * speed * Time.deltaTime);
            }
            else
            {
                gameObject.SetActive(false);
            }
            
        }
    }

    //Meteor can be cleared by shield laser
    public void Clear()
    {
        //Intentionally left blank
    }

    public void Break()
    {
        broken = true;
        StartCoroutine("Breaking");
        //float xOffset = transform.position.x + 0.5f;
        //float yHighOffset = transform.position.y + 0.5f;
        //float yLowOffset = transform.position.y - 0.5f;
        //Spawn smaller meteors at different offsets
        //Vector2[] smallSpawns = { new Vector2(xOffset, transform.position.y), new Vector2(xOffset, yHighOffset), new Vector2(xOffset, yLowOffset) };
        float angle = 60f;
        for (int i = 0; i < 3; i++)
        {
            float meteorDirectionX = transform.position.x + Mathf.Sin((angle * Mathf.PI) / 180f);
            float meteorDirectionY = transform.position.y + Mathf.Cos((angle * Mathf.PI) / 180f);

            Vector3 meteorMoveVector = new Vector3(meteorDirectionX, meteorDirectionY, 0f);
            Vector2 meteorDirection = (meteorMoveVector - transform.position).normalized;
            
            GameObject smallObj = EnemyObjectPool.Instance.SpawnFromPool("SmallMeteor", transform.position, Quaternion.identity);
            SmallMeteor smallData = smallObj.GetComponent<SmallMeteor>();
            smallData.MoveDirection = meteorDirection;

            IPooledObject pooledObj = smallObj.GetComponent<IPooledObject>();
            if (pooledObj != null)
            {
                pooledObj.OnObjectSpawn();
            }
            angle += 30f;
        }
    }

    IEnumerator Breaking()
    {
        rdr.enabled = false;
        meteorCollider.enabled = false;
        breakSound.Play();
        yield return new WaitForSeconds(1.25f);
        gameObject.SetActive(false);

    }
    private void OnDisable()
    {
        Initialized = false;
        broken = false;
        rdr.enabled = true;
        meteorCollider.enabled = true;
    }

    //Damage the player on direct contact
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            IDamageable playerObj = collision.GetComponent<IDamageable>();
            playerObj.TakeDamage(1);
            gameObject.SetActive(false);
        }
    }
}
