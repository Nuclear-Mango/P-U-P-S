﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorSpawner : MonoBehaviour
{
    //Boundaries are used as spawnpoints for meteors
    //private Vector2[] boundaries = { new Vector2(-6f, 3f), new Vector2(-1.5f, 3f), new Vector2(-6f, -4.5f), new Vector2(-1.5f, -4.5f) };
    private bool isChecking;
    private float[] yBoundaries = { 5.5f, -5.5f };
    
    // Update is called once per frame
    void Update()
    {
        int plasmaticCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Plasmatic");
        int beemiusCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Beemius");
        int blastotronCount = EnemyObjectPool.Instance.GetActiveObjectsInPool("Blastotron");
        if (plasmaticCount + beemiusCount + blastotronCount > 0 && !isChecking)
        {
            StartCoroutine("SpawnCheck");
        }
    }

    IEnumerator SpawnCheck()
    {
        isChecking = true;
        yield return new WaitForSeconds(Random.Range(0.5f, 1f));
        //30% chance to spawn a meteor roughly every 9-10 seconds during wave
        int spawnRN = Random.Range(0, 10);
        if (spawnRN >= 0 && spawnRN <= 2)
        {
            SpawnMeteor();
        }
        yield return new WaitForSeconds(9f);
        isChecking = false;
    }

    void SpawnMeteor()
    {
        float ySpawn = yBoundaries[Random.Range(0, yBoundaries.Length)];
        float xSpawn = Random.Range(-6f, -1.5f);
        Vector2 spawnPoint = new Vector2(xSpawn, ySpawn);
        //Spawn the meteor and inform the object of where it is with a setter
        GameObject meteorObj = EnemyObjectPool.Instance.SpawnFromPool("Meteor", spawnPoint, Quaternion.identity);
        BigMeteor meteorData = meteorObj.GetComponent<BigMeteor>();
        meteorData.spawnPoint = spawnPoint;
        IPooledObject pooledObj = meteorObj.GetComponent<IPooledObject>();
        //Enable meteor movement behavior
        if (pooledObj != null)
        {
            pooledObj.OnObjectSpawn();
        }
    }
}
